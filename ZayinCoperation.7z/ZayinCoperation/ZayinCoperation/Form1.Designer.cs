﻿namespace ZayinCoperation
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.entryPnl = new System.Windows.Forms.Panel();
            this.displayLb = new System.Windows.Forms.Label();
            this.closeContInfEntryBtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            this.ClientsConInf = new System.Windows.Forms.Label();
            this.saveBtn = new System.Windows.Forms.Button();
            this.occupationTb = new System.Windows.Forms.TextBox();
            this.addressTb = new System.Windows.Forms.TextBox();
            this.phoneTb = new System.Windows.Forms.TextBox();
            this.countryTb = new System.Windows.Forms.TextBox();
            this.locationTb = new System.Windows.Forms.TextBox();
            this.occupationLb = new System.Windows.Forms.Label();
            this.phoneLb = new System.Windows.Forms.Label();
            this.locationLb = new System.Windows.Forms.Label();
            this.addressLb = new System.Windows.Forms.Label();
            this.countryLb = new System.Windows.Forms.Label();
            this.nameLb = new System.Windows.Forms.Label();
            this.nameTb = new System.Windows.Forms.TextBox();
            this.mainPnl = new System.Windows.Forms.Panel();
            this.mainWindowInfoLbl = new System.Windows.Forms.Label();
            this.exitBtn = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.edictBtn = new System.Windows.Forms.Button();
            this.viewBtn = new System.Windows.Forms.Button();
            this.addClientDataBtn = new System.Windows.Forms.Button();
            this.savedClientsPnl = new System.Windows.Forms.Panel();
            this.editAndInfoPanel = new System.Windows.Forms.Panel();
            this.edictPanel = new System.Windows.Forms.Panel();
            this.updateInfoDisplayLbl = new System.Windows.Forms.Label();
            this.edictTextBoxLbl = new System.Windows.Forms.Label();
            this.edictRichTextBox = new System.Windows.Forms.RichTextBox();
            this.edictSaveBtn = new System.Windows.Forms.Button();
            this.InfoDisplayPnl = new System.Windows.Forms.Panel();
            this.displayClientInfoLbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.backbtn2 = new System.Windows.Forms.Button();
            this.mainDeleteBtn = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.clientsPnl = new System.Windows.Forms.Panel();
            this.savedClientNames = new System.Windows.Forms.ListBox();
            this.clientNameBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.entryPnl.SuspendLayout();
            this.mainPnl.SuspendLayout();
            this.savedClientsPnl.SuspendLayout();
            this.editAndInfoPanel.SuspendLayout();
            this.edictPanel.SuspendLayout();
            this.InfoDisplayPnl.SuspendLayout();
            this.clientsPnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // entryPnl
            // 
            this.entryPnl.AutoSize = true;
            this.entryPnl.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.entryPnl.Controls.Add(this.displayLb);
            this.entryPnl.Controls.Add(this.closeContInfEntryBtn);
            this.entryPnl.Controls.Add(this.backBtn);
            this.entryPnl.Controls.Add(this.ClientsConInf);
            this.entryPnl.Controls.Add(this.saveBtn);
            this.entryPnl.Controls.Add(this.occupationTb);
            this.entryPnl.Controls.Add(this.addressTb);
            this.entryPnl.Controls.Add(this.phoneTb);
            this.entryPnl.Controls.Add(this.countryTb);
            this.entryPnl.Controls.Add(this.locationTb);
            this.entryPnl.Controls.Add(this.occupationLb);
            this.entryPnl.Controls.Add(this.phoneLb);
            this.entryPnl.Controls.Add(this.locationLb);
            this.entryPnl.Controls.Add(this.addressLb);
            this.entryPnl.Controls.Add(this.countryLb);
            this.entryPnl.Controls.Add(this.nameLb);
            this.entryPnl.Controls.Add(this.nameTb);
            this.entryPnl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.entryPnl.Location = new System.Drawing.Point(606, 3);
            this.entryPnl.Name = "entryPnl";
            this.entryPnl.Size = new System.Drawing.Size(597, 552);
            this.entryPnl.TabIndex = 0;
            this.entryPnl.Visible = false;
            this.entryPnl.Paint += new System.Windows.Forms.PaintEventHandler(this.EntryPnl_Paint);
            // 
            // displayLb
            // 
            this.displayLb.AutoSize = true;
            this.displayLb.Location = new System.Drawing.Point(232, 410);
            this.displayLb.Name = "displayLb";
            this.displayLb.Size = new System.Drawing.Size(52, 17);
            this.displayLb.TabIndex = 17;
            this.displayLb.Text = "display";
            this.displayLb.Visible = false;
            this.displayLb.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // closeContInfEntryBtn
            // 
            this.closeContInfEntryBtn.BackColor = System.Drawing.Color.Indigo;
            this.closeContInfEntryBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.closeContInfEntryBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeContInfEntryBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.closeContInfEntryBtn.Location = new System.Drawing.Point(511, 520);
            this.closeContInfEntryBtn.Name = "closeContInfEntryBtn";
            this.closeContInfEntryBtn.Size = new System.Drawing.Size(72, 29);
            this.closeContInfEntryBtn.TabIndex = 8;
            this.closeContInfEntryBtn.Text = "Exit";
            this.closeContInfEntryBtn.UseVisualStyleBackColor = false;
            this.closeContInfEntryBtn.Click += new System.EventHandler(this.closeContInfEntryBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Indigo;
            this.backBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.backBtn.Location = new System.Drawing.Point(42, 520);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(139, 29);
            this.backBtn.TabIndex = 7;
            this.backBtn.Text = "Option Window";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // ClientsConInf
            // 
            this.ClientsConInf.AutoSize = true;
            this.ClientsConInf.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ClientsConInf.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClientsConInf.Location = new System.Drawing.Point(140, 25);
            this.ClientsConInf.Name = "ClientsConInf";
            this.ClientsConInf.Size = new System.Drawing.Size(275, 20);
            this.ClientsConInf.TabIndex = 13;
            this.ClientsConInf.Text = "Enter Contact Information Of Client";
            // 
            // saveBtn
            // 
            this.saveBtn.BackColor = System.Drawing.Color.Indigo;
            this.saveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.saveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.saveBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.saveBtn.Location = new System.Drawing.Point(246, 301);
            this.saveBtn.Name = "saveBtn";
            this.saveBtn.Size = new System.Drawing.Size(101, 29);
            this.saveBtn.TabIndex = 6;
            this.saveBtn.Text = "Save";
            this.saveBtn.UseVisualStyleBackColor = false;
            this.saveBtn.Click += new System.EventHandler(this.SaveBtn_Click);
            // 
            // occupationTb
            // 
            this.occupationTb.Location = new System.Drawing.Point(93, 205);
            this.occupationTb.Name = "occupationTb";
            this.occupationTb.Size = new System.Drawing.Size(141, 23);
            this.occupationTb.TabIndex = 4;
            this.occupationTb.TextChanged += new System.EventHandler(this.occupationTb_TextChanged);
            // 
            // addressTb
            // 
            this.addressTb.Location = new System.Drawing.Point(373, 152);
            this.addressTb.Name = "addressTb";
            this.addressTb.Size = new System.Drawing.Size(141, 23);
            this.addressTb.TabIndex = 3;
            this.addressTb.TextChanged += new System.EventHandler(this.AddressTb_TextChanged);
            // 
            // phoneTb
            // 
            this.phoneTb.Location = new System.Drawing.Point(65, 155);
            this.phoneTb.Name = "phoneTb";
            this.phoneTb.Size = new System.Drawing.Size(136, 23);
            this.phoneTb.TabIndex = 2;
            // 
            // countryTb
            // 
            this.countryTb.Location = new System.Drawing.Point(373, 110);
            this.countryTb.Name = "countryTb";
            this.countryTb.Size = new System.Drawing.Size(141, 23);
            this.countryTb.TabIndex = 1;
            // 
            // locationTb
            // 
            this.locationTb.Location = new System.Drawing.Point(373, 202);
            this.locationTb.Name = "locationTb";
            this.locationTb.Size = new System.Drawing.Size(141, 23);
            this.locationTb.TabIndex = 5;
            // 
            // occupationLb
            // 
            this.occupationLb.AutoSize = true;
            this.occupationLb.Location = new System.Drawing.Point(3, 205);
            this.occupationLb.Name = "occupationLb";
            this.occupationLb.Size = new System.Drawing.Size(84, 17);
            this.occupationLb.TabIndex = 6;
            this.occupationLb.Text = " Occupation";
            // 
            // phoneLb
            // 
            this.phoneLb.AutoSize = true;
            this.phoneLb.Location = new System.Drawing.Point(10, 158);
            this.phoneLb.Name = "phoneLb";
            this.phoneLb.Size = new System.Drawing.Size(53, 17);
            this.phoneLb.TabIndex = 5;
            this.phoneLb.Text = " Phone";
            this.phoneLb.Click += new System.EventHandler(this.label5_Click);
            // 
            // locationLb
            // 
            this.locationLb.AutoSize = true;
            this.locationLb.Location = new System.Drawing.Point(294, 208);
            this.locationLb.Name = "locationLb";
            this.locationLb.Size = new System.Drawing.Size(66, 17);
            this.locationLb.TabIndex = 4;
            this.locationLb.Text = " Location";
            // 
            // addressLb
            // 
            this.addressLb.AutoSize = true;
            this.addressLb.Location = new System.Drawing.Point(300, 158);
            this.addressLb.Name = "addressLb";
            this.addressLb.Size = new System.Drawing.Size(60, 17);
            this.addressLb.TabIndex = 3;
            this.addressLb.Text = "Address";
            // 
            // countryLb
            // 
            this.countryLb.AutoSize = true;
            this.countryLb.Location = new System.Drawing.Point(299, 110);
            this.countryLb.Name = "countryLb";
            this.countryLb.Size = new System.Drawing.Size(78, 17);
            this.countryLb.TabIndex = 2;
            this.countryLb.Text = " Nationality";
            // 
            // nameLb
            // 
            this.nameLb.AutoSize = true;
            this.nameLb.Location = new System.Drawing.Point(10, 110);
            this.nameLb.Name = "nameLb";
            this.nameLb.Size = new System.Drawing.Size(49, 17);
            this.nameLb.TabIndex = 1;
            this.nameLb.Text = " Name";
            // 
            // nameTb
            // 
            this.nameTb.Location = new System.Drawing.Point(65, 107);
            this.nameTb.Name = "nameTb";
            this.nameTb.Size = new System.Drawing.Size(141, 23);
            this.nameTb.TabIndex = 0;
            // 
            // mainPnl
            // 
            this.mainPnl.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.mainPnl.Controls.Add(this.mainWindowInfoLbl);
            this.mainPnl.Controls.Add(this.exitBtn);
            this.mainPnl.Controls.Add(this.label4);
            this.mainPnl.Controls.Add(this.edictBtn);
            this.mainPnl.Controls.Add(this.viewBtn);
            this.mainPnl.Controls.Add(this.addClientDataBtn);
            this.mainPnl.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mainPnl.Location = new System.Drawing.Point(1, 3);
            this.mainPnl.Name = "mainPnl";
            this.mainPnl.Size = new System.Drawing.Size(596, 404);
            this.mainPnl.TabIndex = 1;
            this.mainPnl.Paint += new System.Windows.Forms.PaintEventHandler(this.mainPnl_Paint);
            // 
            // mainWindowInfoLbl
            // 
            this.mainWindowInfoLbl.AutoSize = true;
            this.mainWindowInfoLbl.ForeColor = System.Drawing.SystemColors.ControlText;
            this.mainWindowInfoLbl.Location = new System.Drawing.Point(239, 226);
            this.mainWindowInfoLbl.Name = "mainWindowInfoLbl";
            this.mainWindowInfoLbl.Size = new System.Drawing.Size(41, 15);
            this.mainWindowInfoLbl.TabIndex = 14;
            this.mainWindowInfoLbl.Text = "label3";
            this.mainWindowInfoLbl.Visible = false;
            // 
            // exitBtn
            // 
            this.exitBtn.BackColor = System.Drawing.Color.Indigo;
            this.exitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.exitBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.exitBtn.Location = new System.Drawing.Point(225, 353);
            this.exitBtn.Name = "exitBtn";
            this.exitBtn.Size = new System.Drawing.Size(101, 29);
            this.exitBtn.TabIndex = 13;
            this.exitBtn.Text = "Exit";
            this.exitBtn.UseVisualStyleBackColor = false;
            this.exitBtn.Click += new System.EventHandler(this.exitBtn_Click_1);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.label4.Location = new System.Drawing.Point(127, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(248, 20);
            this.label4.TabIndex = 4;
            this.label4.Text = "Zayin Coperation\'s Clients Data";
            // 
            // edictBtn
            // 
            this.edictBtn.BackColor = System.Drawing.Color.Indigo;
            this.edictBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.edictBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edictBtn.Location = new System.Drawing.Point(193, 158);
            this.edictBtn.Name = "edictBtn";
            this.edictBtn.Size = new System.Drawing.Size(173, 29);
            this.edictBtn.TabIndex = 2;
            this.edictBtn.Text = "Edict Client\'s Data";
            this.edictBtn.UseVisualStyleBackColor = false;
            this.edictBtn.Click += new System.EventHandler(this.edictBtn_Click);
            // 
            // viewBtn
            // 
            this.viewBtn.BackColor = System.Drawing.Color.Indigo;
            this.viewBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.viewBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.viewBtn.Location = new System.Drawing.Point(193, 111);
            this.viewBtn.Name = "viewBtn";
            this.viewBtn.Size = new System.Drawing.Size(173, 29);
            this.viewBtn.TabIndex = 1;
            this.viewBtn.Text = "View Client\'s Data";
            this.viewBtn.UseVisualStyleBackColor = false;
            this.viewBtn.Click += new System.EventHandler(this.viewBtn_Click);
            // 
            // addClientDataBtn
            // 
            this.addClientDataBtn.BackColor = System.Drawing.Color.Indigo;
            this.addClientDataBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addClientDataBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addClientDataBtn.Location = new System.Drawing.Point(193, 76);
            this.addClientDataBtn.Name = "addClientDataBtn";
            this.addClientDataBtn.Size = new System.Drawing.Size(173, 29);
            this.addClientDataBtn.TabIndex = 0;
            this.addClientDataBtn.Text = "Add Client\'s  Data";
            this.addClientDataBtn.UseVisualStyleBackColor = false;
            this.addClientDataBtn.Click += new System.EventHandler(this.AddClientDataBtn_Click);
            // 
            // savedClientsPnl
            // 
            this.savedClientsPnl.AutoSize = true;
            this.savedClientsPnl.Controls.Add(this.editAndInfoPanel);
            this.savedClientsPnl.Controls.Add(this.button11);
            this.savedClientsPnl.Controls.Add(this.backbtn2);
            this.savedClientsPnl.Controls.Add(this.mainDeleteBtn);
            this.savedClientsPnl.Controls.Add(this.button6);
            this.savedClientsPnl.Controls.Add(this.clientsPnl);
            this.savedClientsPnl.Location = new System.Drawing.Point(1, 413);
            this.savedClientsPnl.Name = "savedClientsPnl";
            this.savedClientsPnl.Size = new System.Drawing.Size(599, 479);
            this.savedClientsPnl.TabIndex = 2;
            this.savedClientsPnl.Visible = false;
            // 
            // editAndInfoPanel
            // 
            this.editAndInfoPanel.Controls.Add(this.edictPanel);
            this.editAndInfoPanel.Controls.Add(this.InfoDisplayPnl);
            this.editAndInfoPanel.Location = new System.Drawing.Point(190, 3);
            this.editAndInfoPanel.Name = "editAndInfoPanel";
            this.editAndInfoPanel.Size = new System.Drawing.Size(406, 383);
            this.editAndInfoPanel.TabIndex = 18;
            // 
            // edictPanel
            // 
            this.edictPanel.AutoSize = true;
            this.edictPanel.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.edictPanel.Controls.Add(this.updateInfoDisplayLbl);
            this.edictPanel.Controls.Add(this.edictTextBoxLbl);
            this.edictPanel.Controls.Add(this.edictRichTextBox);
            this.edictPanel.Controls.Add(this.edictSaveBtn);
            this.edictPanel.Location = new System.Drawing.Point(14, 152);
            this.edictPanel.Name = "edictPanel";
            this.edictPanel.Size = new System.Drawing.Size(375, 223);
            this.edictPanel.TabIndex = 14;
            // 
            // updateInfoDisplayLbl
            // 
            this.updateInfoDisplayLbl.AutoSize = true;
            this.updateInfoDisplayLbl.Location = new System.Drawing.Point(153, 204);
            this.updateInfoDisplayLbl.Name = "updateInfoDisplayLbl";
            this.updateInfoDisplayLbl.Size = new System.Drawing.Size(51, 15);
            this.updateInfoDisplayLbl.TabIndex = 15;
            this.updateInfoDisplayLbl.Text = "updates";
            this.updateInfoDisplayLbl.Visible = false;
            // 
            // edictTextBoxLbl
            // 
            this.edictTextBoxLbl.AutoSize = true;
            this.edictTextBoxLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edictTextBoxLbl.Location = new System.Drawing.Point(70, 9);
            this.edictTextBoxLbl.Name = "edictTextBoxLbl";
            this.edictTextBoxLbl.Size = new System.Drawing.Size(255, 15);
            this.edictTextBoxLbl.TabIndex = 14;
            this.edictTextBoxLbl.Text = "Select name from the list to edict here.";
            // 
            // edictRichTextBox
            // 
            this.edictRichTextBox.Location = new System.Drawing.Point(35, 36);
            this.edictRichTextBox.Name = "edictRichTextBox";
            this.edictRichTextBox.Size = new System.Drawing.Size(302, 120);
            this.edictRichTextBox.TabIndex = 3;
            this.edictRichTextBox.Text = "";
            // 
            // edictSaveBtn
            // 
            this.edictSaveBtn.BackColor = System.Drawing.Color.Indigo;
            this.edictSaveBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.edictSaveBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.edictSaveBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.edictSaveBtn.Location = new System.Drawing.Point(136, 162);
            this.edictSaveBtn.Name = "edictSaveBtn";
            this.edictSaveBtn.Size = new System.Drawing.Size(101, 29);
            this.edictSaveBtn.TabIndex = 13;
            this.edictSaveBtn.Text = "Save";
            this.edictSaveBtn.UseVisualStyleBackColor = false;
            this.edictSaveBtn.Click += new System.EventHandler(this.edictSaveBtn_Click);
            // 
            // InfoDisplayPnl
            // 
            this.InfoDisplayPnl.AutoSize = true;
            this.InfoDisplayPnl.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.InfoDisplayPnl.Controls.Add(this.displayClientInfoLbl);
            this.InfoDisplayPnl.Controls.Add(this.label2);
            this.InfoDisplayPnl.Location = new System.Drawing.Point(3, 3);
            this.InfoDisplayPnl.Name = "InfoDisplayPnl";
            this.InfoDisplayPnl.Size = new System.Drawing.Size(403, 143);
            this.InfoDisplayPnl.TabIndex = 1;
            this.InfoDisplayPnl.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // displayClientInfoLbl
            // 
            this.displayClientInfoLbl.AutoSize = true;
            this.displayClientInfoLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.displayClientInfoLbl.Location = new System.Drawing.Point(91, 53);
            this.displayClientInfoLbl.Name = "displayClientInfoLbl";
            this.displayClientInfoLbl.Size = new System.Drawing.Size(170, 17);
            this.displayClientInfoLbl.TabIndex = 3;
            this.displayClientInfoLbl.Text = "display clients Information";
            this.displayClientInfoLbl.Click += new System.EventHandler(this.displayClientInfoLbl_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(91, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(224, 18);
            this.label2.TabIndex = 2;
            this.label2.Text = "Selected Client\'s Information";
            this.label2.Visible = false;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.Indigo;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button11.Location = new System.Drawing.Point(495, 434);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(101, 29);
            this.button11.TabIndex = 17;
            this.button11.Text = "Exit";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // backbtn2
            // 
            this.backbtn2.BackColor = System.Drawing.Color.Indigo;
            this.backbtn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.backbtn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backbtn2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.backbtn2.Location = new System.Drawing.Point(193, 434);
            this.backbtn2.Name = "backbtn2";
            this.backbtn2.Size = new System.Drawing.Size(133, 29);
            this.backbtn2.TabIndex = 16;
            this.backbtn2.Text = "Option Window";
            this.backbtn2.UseVisualStyleBackColor = false;
            this.backbtn2.Click += new System.EventHandler(this.backbtn2_Click);
            // 
            // mainDeleteBtn
            // 
            this.mainDeleteBtn.BackColor = System.Drawing.Color.Indigo;
            this.mainDeleteBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mainDeleteBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainDeleteBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.mainDeleteBtn.Location = new System.Drawing.Point(474, 392);
            this.mainDeleteBtn.Name = "mainDeleteBtn";
            this.mainDeleteBtn.Size = new System.Drawing.Size(122, 29);
            this.mainDeleteBtn.TabIndex = 3;
            this.mainDeleteBtn.Text = "Delete";
            this.mainDeleteBtn.UseVisualStyleBackColor = false;
            this.mainDeleteBtn.Click += new System.EventHandler(this.mainDeleteBtn_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Indigo;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.button6.Location = new System.Drawing.Point(193, 392);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(122, 29);
            this.button6.TabIndex = 2;
            this.button6.Text = "Edict";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.edictBtn_Click);
            // 
            // clientsPnl
            // 
            this.clientsPnl.AutoSize = true;
            this.clientsPnl.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.clientsPnl.Controls.Add(this.savedClientNames);
            this.clientsPnl.Controls.Add(this.clientNameBtn);
            this.clientsPnl.Controls.Add(this.label1);
            this.clientsPnl.Controls.Add(this.splitter1);
            this.clientsPnl.Location = new System.Drawing.Point(3, 3);
            this.clientsPnl.Name = "clientsPnl";
            this.clientsPnl.Size = new System.Drawing.Size(184, 473);
            this.clientsPnl.TabIndex = 0;
            // 
            // savedClientNames
            // 
            this.savedClientNames.Cursor = System.Windows.Forms.Cursors.Hand;
            this.savedClientNames.FormattingEnabled = true;
            this.savedClientNames.ItemHeight = 15;
            this.savedClientNames.Location = new System.Drawing.Point(3, 66);
            this.savedClientNames.Name = "savedClientNames";
            this.savedClientNames.Size = new System.Drawing.Size(172, 394);
            this.savedClientNames.TabIndex = 4;
            this.savedClientNames.TabStop = false;
            this.savedClientNames.Click += new System.EventHandler(this.clientNameBtn_Click);
            // 
            // clientNameBtn
            // 
            this.clientNameBtn.BackColor = System.Drawing.Color.Indigo;
            this.clientNameBtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.clientNameBtn.Location = new System.Drawing.Point(0, 39);
            this.clientNameBtn.Name = "clientNameBtn";
            this.clientNameBtn.Size = new System.Drawing.Size(181, 21);
            this.clientNameBtn.TabIndex = 2;
            this.clientNameBtn.Text = "Contacs";
            this.clientNameBtn.UseVisualStyleBackColor = false;
            this.clientNameBtn.Visible = false;
            this.clientNameBtn.Click += new System.EventHandler(this.clientNameBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(56, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Clients";
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(0, 0);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(3, 473);
            this.splitter1.TabIndex = 0;
            this.splitter1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1226, 881);
            this.Controls.Add(this.savedClientsPnl);
            this.Controls.Add(this.mainPnl);
            this.Controls.Add(this.entryPnl);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Zayin Coperation";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.entryPnl.ResumeLayout(false);
            this.entryPnl.PerformLayout();
            this.mainPnl.ResumeLayout(false);
            this.mainPnl.PerformLayout();
            this.savedClientsPnl.ResumeLayout(false);
            this.savedClientsPnl.PerformLayout();
            this.editAndInfoPanel.ResumeLayout(false);
            this.editAndInfoPanel.PerformLayout();
            this.edictPanel.ResumeLayout(false);
            this.edictPanel.PerformLayout();
            this.InfoDisplayPnl.ResumeLayout(false);
            this.InfoDisplayPnl.PerformLayout();
            this.clientsPnl.ResumeLayout(false);
            this.clientsPnl.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel entryPnl;
        private System.Windows.Forms.TextBox addressTb;
        private System.Windows.Forms.TextBox phoneTb;
        private System.Windows.Forms.TextBox countryTb;
        private System.Windows.Forms.TextBox locationTb;
        private System.Windows.Forms.Label occupationLb;
        private System.Windows.Forms.Label phoneLb;
        private System.Windows.Forms.Label locationLb;
        private System.Windows.Forms.Label addressLb;
        private System.Windows.Forms.Label countryLb;
        private System.Windows.Forms.Label nameLb;
        private System.Windows.Forms.TextBox nameTb;
        private System.Windows.Forms.Label ClientsConInf;
        private System.Windows.Forms.Button saveBtn;
        private System.Windows.Forms.TextBox occupationTb;
        private System.Windows.Forms.Panel mainPnl;
        private System.Windows.Forms.Button edictBtn;
        private System.Windows.Forms.Button viewBtn;
        private System.Windows.Forms.Button addClientDataBtn;
        private System.Windows.Forms.Panel savedClientsPnl;
        private System.Windows.Forms.Panel InfoDisplayPnl;
        private System.Windows.Forms.Button mainDeleteBtn;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label displayClientInfoLbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button closeContInfEntryBtn;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Button exitBtn;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button backbtn2;
        private System.Windows.Forms.Label displayLb;
        private System.Windows.Forms.ListBox savedClientNames;
        private System.Windows.Forms.Panel clientsPnl;
        private System.Windows.Forms.Button clientNameBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.RichTextBox edictRichTextBox;
        private System.Windows.Forms.Button edictSaveBtn;
        private System.Windows.Forms.Panel edictPanel;
        private System.Windows.Forms.Panel editAndInfoPanel;
        private System.Windows.Forms.Label edictTextBoxLbl;
        private System.Windows.Forms.Label updateInfoDisplayLbl;
        private System.Windows.Forms.Label mainWindowInfoLbl;
    }
}

