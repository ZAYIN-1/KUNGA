﻿// This program is written and developed by Francis Ofori Anane (Zayin)
//STARTED DATE: Thursday 28th November 2018 @ 11pm
//Updated: Friday 29th November 2018 @ 3am





using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZayinCoperation
{
    public partial class Form1 : Form
    {
    

        
        

     
        public Form1()
        {
            InitializeComponent();
        }


 

        
        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void EntryPnl_Paint(object sender, PaintEventArgs e)
        {

        }

        private void AddressTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void AddClientDataBtn_Click(object sender, EventArgs e)
        {
            mainWindowInfoLbl.Visible = false;
            this.entryPnl.Visible = true;
            
            this.mainPnl.Visible = false;
            this.entryPnl.Dock = System.Windows.Forms.DockStyle.Fill;



        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
        
        // go to tho options window 
        private void goBack()
        {
            entryPnl.Visible = false;
            savedClientsPnl.Visible = false;
            mainPnl.Visible = true;
        }
        string thePath = @"C:\Users\FRANCIS OFORI ANANE\source\repos\ZayinCoperation\ZayinCoperation\SystemClientFiles\";//the path to the file to be read
        string namesPath = @"C:\Users\FRANCIS OFORI ANANE\source\repos\ZayinCoperation\ZayinCoperation\SystemClientFiles\NamesDataFile.txt";
         
        string theFileName; // string to store the file name in for a particular clients data file
        private void SaveBtn_Click(object sender, EventArgs e)
        {

            string clientName = nameTb.Text;

            string phoneNumber = phoneTb.Text;


            string _country = countryTb.Text;

            string _occupation = occupationTb.Text;

            string _address = addressTb.Text;

            string _location = locationTb.Text;

            theFileName = clientName;// this will be name for the particular clients data file 

            //System.IO.File.




            //label5.Text = "Empty Fields detected";
            //label5.Visible = true;


            // An array to style how the contact information is to be written
            String[] contactInformation = new string[] {"Name: " + clientName, "Phone: " + phoneNumber, "Country: " + _country, "Occupation: " +  _occupation, "Adress: " + _address, "Location: " + _location, "\n \n" };
            
            string[] namesData ={ nameTb.Text };// get the name field of the client to be save in file for use on client name buttons

            if(clientName == string.Empty || phoneNumber == string.Empty || _country == string.Empty || _location == string.Empty || _location == string.Empty || _address == string.Empty)
            {
                displayLb.Text = "Empty fields detected!\n\nPlease all fields are required!"; // information to show when the entry field is left empty
                displayLb.Visible = true;
            }
            else
            {

                //displayLb.Visible = false;

                //Save the name of a client in a file
                System.IO.File.AppendAllLines(thePath + "NamesDataFile.txt", namesData);

                // Write the entry fields to a file when the are all filled
                System.IO.File.AppendAllLines(thePath + theFileName + ".dat", contactInformation);
                displayLb.Text = "Successfully Saved!";

                // These lines set the entry fields back to empty
                nameTb.Text = string.Empty;

                phoneTb.Text = string.Empty;

                countryTb.Text = string.Empty;

                occupationTb.Text = string.Empty;

                addressTb.Text = string.Empty;

                locationTb.Text = string.Empty; 



            }

            
            


            }










         private void mainPnl_Paint(object sender, PaintEventArgs e)
        {

        }

        

        // Display each clients name from the read names data file
        private void setClientNamesList()
        {
            savedClientNames.Items.Clear();

            if (System.IO.File.Exists(namesPath))
            {
                // read the file the stores the clien names
                string[] listOfNames = System.IO.File.ReadAllLines(namesPath);


                foreach (string lin in listOfNames)
                {
                    if(System.IO.File.Exists(thePath + lin + ".dat"))
                    {
                        savedClientNames.Items.Add(lin);

                    }


                    


                }

            }
            else
            {
                mainWindowInfoLbl.Visible = true;
                mainWindowInfoLbl.Text = "Notting added yet\n Please add data to view";
                mainPnl.Visible = true;
                savedClientsPnl.Visible = false;
            }

            displayClientInfoLbl.Text = string.Empty;

            
        }

        // sets the file name for each particular client
        private void checkForFile()
        {
            updateNames();
            
           
            string[] currentFileName = System.IO.File.ReadAllLines(namesPath);
            for(int i=0; i<currentFileName.Length; i++)
            {
                if (savedClientNames.GetSelected(i))
                {
                    theFileName = currentFileName[i];
                }
                
            }

            

            
        }

        //update the clients name file
        private void updateNames()
        {
            
            string[] namesData = System.IO.File.ReadAllLines(namesPath);
            List<string> newNames = new List<string>() { };
            foreach(string lin in namesData)
            {
                if(System.IO.File.Exists(thePath + lin + ".dat"))
                {
                    newNames.Add(lin);
                   


                }
                else
                {
                    continue;
                }
            }
            System.IO.File.WriteAllLines(namesPath, newNames);
        }

        // set the name of the file to be removed


        private void checkForFileToRemove()
        {


            edictRichTextBox.Text = string.Empty;
            checkForFile();
            System.IO.File.Delete(thePath + theFileName + ".dat");
            updateNames();
            checkForFile();
            setClientNamesList();
            edictRichTextBox.Text = string.Empty;


        }


        // a method to get the recorded contact information from a file
        private string[] getContactInFormation()
        { 
            string[] contactData = { };

            if (System.IO.File.Exists(thePath + theFileName + ".dat"))
            {
                contactData = System.IO.File.ReadAllLines(thePath + theFileName + ".dat");

            }

                
            return contactData;
        }

        private void viewBtn_Click(object sender, EventArgs e)
        {
            
            this.InfoDisplayPnl.Visible = true;
            this.savedClientsPnl.Visible = true;
            InfoDisplayPnl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainPnl.Visible = false;
            edictPanel.Visible = false;
            


            this.savedClientsPnl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.displayClientInfoLbl.Text = string.Empty; // set the label to display client info to empty
            string clientNameBtnText = string.Empty;// set the text for the clientNameBtn to empty at Initialization
            this.savedClientNames.Items.Clear();
            setClientNamesList();
           



            
        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            
        }

        private void occupationTb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void displayClientInfoLbl_Click(object sender, EventArgs e)
        {

        }

        private void clientNameBtn_Click(object sender, EventArgs e)
        {
            label2.Visible = true;
            updateInfoDisplayLbl.Visible = false;
            this.displayClientInfoLbl.Text = string.Empty;
            this.edictRichTextBox.Text = String.Empty;
            checkForFile();
            string[] contactData = getContactInFormation();
            foreach (string lin in contactData)
            {
                this.displayClientInfoLbl.Text += lin + "\n";
                this.edictRichTextBox.Text += lin + "\n";


            }
            checkForFile();


        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            goBack();

        }

        private void button11_Click(object sender, EventArgs e)
        {
            savedClientsPnl.Visible = false;
            

        }

        private void exitBtn_Click_1(object sender, EventArgs e)
        {
            mainPnl.Visible = false;
        }

        private void closeContInfEntryBtn_Click(object sender, EventArgs e)
        {
            entryPnl.Visible = false;
            
        }

        
        private void edictBtn_Click(object sender, EventArgs e)
        {
            updateInfoDisplayLbl.Visible = false;
            this.edictRichTextBox.Text = String.Empty;
            savedClientsPnl.Visible = true;
            edictPanel.Visible = true;
            edictPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.savedClientsPnl.Dock = System.Windows.Forms.DockStyle.Fill;
            mainPnl.Visible = false;
            InfoDisplayPnl.Visible = false;
            this.savedClientNames.Items.Clear();
            setClientNamesList();



        }

        private void edictSaveBtn_Click(object sender, EventArgs e)
        {
            checkForFile();
            updateInfoDisplayLbl.Visible = true;
            string[] checkingData = getContactInFormation();
            string[] updatedInfo = edictRichTextBox.Text.Split('\n');

            if(edictRichTextBox.Text == string.Empty)
            {
                updateInfoDisplayLbl.Text = "Notting To Update!";
                edictRichTextBox.Text = string.Empty;

            }
            else if(edictRichTextBox.Text != string.Empty)
            {
                System.IO.File.WriteAllLines(thePath + theFileName + ".dat", updatedInfo);
               
                updateInfoDisplayLbl.Text = "Successfuly Update!";
                edictRichTextBox.Text = string.Empty;
            }
            else

            {
                updateInfoDisplayLbl.Text = "No changes made.";
            }



            setClientNamesList();



        }

        private void mainDeleteBtn_Click(object sender, EventArgs e)
        {
            checkForFileToRemove();
            
            
        }

        private void backbtn2_Click(object sender, EventArgs e)
        {
            goBack();
        }
    }
}

